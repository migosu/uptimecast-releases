#!/usr/bin/env bash
# UptimeCast installer for Ubuntu 20.04/22.04/24.04/26.04 and Debian 11/12/13.
#
# It only ever creates its own things: a system user, its own folders, its own
# PostgreSQL database and role, and its own systemd service. It never drops,
# alters or empties any other database, never touches MySQL/MariaDB, and never
# stops other services. Run it again to upgrade.
#
#   sudo ./install.sh                 install or upgrade
#   sudo ./install.sh --dry-run       show what it would do, change nothing
#   sudo ./install.sh --prefix /home/me/web/uptimecast --run-as me
#                                     everything in one folder, run as an existing user
#   sudo ./install.sh --lang es       Spanish without asking (en, es, fr, pt, ar, tr, de, it, ru, zh)
#   sudo ./install.sh --help          all options
#
# Before installing it asks which language to use; the installer then speaks
# that language and the panel starts in it. Its texts come from the uptimecast
# program itself ("uptimecast i18n"), so they are the same ten languages.
set -Eeuo pipefail

VERSION_FILE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SERVICE=/etc/systemd/system/uptimecast.service
SYS_USER=uptimecast
PREFIX=""
RUN_AS=""
FFMPEG_BIN=""
FFPROBE_BIN=""
LICENSE_KEY=""

DRY_RUN=0
ASSUME_YES=0
PORT=8080
PORT_SET=0
DB_NAME=uptimecast
DB_USER=uptimecast
ADMIN_USER=admin
ADMIN_PASS=""
BINARY=""
INSTALL_DEPS=1
FORCE_OS=0
LANG_OPT=""
SHOW_HELP=0
BAD_OPT=""

# ---- messages ------------------------------------------------------------------
# Every text comes from the uptimecast binary next to this script, in the
# language chosen at the start (L). Until that binary is found, English.
TBIN=""
L=""
t() {
  local key=$1; shift
  if [ -n "$TBIN" ] && "$TBIN" i18n -lang "${L:-en}" "$key" "$@" 2>/dev/null; then return 0; fi
  printf '%s\n' "$key"
}
info() { printf '\033[1m==>\033[0m %s\n' "$(t "$@")"; }
warn() { printf '\033[33m!!\033[0m  %s\n' "$(t "$@")" >&2; }
die()  { printf '\033[31mxx\033[0m  %s\n' "$(t "$@")" >&2; exit 1; }
plan() { PLAN+=("$(t "$@")"); }
fatal() { printf '\033[31mxx\033[0m  %s\n' "$1" >&2; exit 1; } # before the binary is known: English only
PLAN=()

# The system's language, used as the default choice.
sys_lang() {
  case "${LC_ALL:-${LC_MESSAGES:-${LANG:-}}}" in
    es*) echo es ;; fr*) echo fr ;; pt*) echo pt ;; ar*) echo ar ;; tr*) echo tr ;;
    de*) echo de ;; it*) echo it ;; ru*) echo ru ;; zh*) echo zh ;; *) echo en ;;
  esac
}

usage() {
  printf '%s\n\n' "$(t inst.title)"
  printf '  %-23s %s\n' \
    "--lang CODE" "$(t inst.opt.lang)" \
    "--dry-run" "$(t inst.opt.dryrun)" \
    "--port N" "$(t inst.opt.port)" \
    "--db-name NAME" "$(t inst.opt.dbname)" \
    "--db-user NAME" "$(t inst.opt.dbuser)" \
    "--admin-user NAME" "$(t inst.opt.adminuser)" \
    "--admin-password PASS" "$(t inst.opt.adminpass)" \
    "--binary PATH" "$(t inst.opt.binary)" \
    "--prefix DIR" "$(t inst.opt.prefix)" \
    "--run-as USER" "$(t inst.opt.runas)" \
    "--ffmpeg PATH" "$(t inst.opt.ffmpeg)" \
    "--license KEY" "$(t inst.opt.license)" \
    "--no-install-deps" "$(t inst.opt.nodeps)" \
    "--yes" "$(t inst.opt.yes)" \
    "--force-os" "$(t inst.opt.forceos)"
}

while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run) DRY_RUN=1 ;;
    --port) PORT="${2:?}"; PORT_SET=1; shift ;;
    --db-name) DB_NAME="${2:?}"; shift ;;
    --db-user) DB_USER="${2:?}"; shift ;;
    --admin-user) ADMIN_USER="${2:?}"; shift ;;
    --admin-password) ADMIN_PASS="${2:?}"; shift ;;
    --binary) BINARY="${2:?}"; shift ;;
    --prefix) PREFIX="${2:?}"; shift ;;
    --run-as) RUN_AS="${2:?}"; shift ;;
    --ffmpeg) FFMPEG_BIN="${2:?}"; shift ;;
    --ffprobe) FFPROBE_BIN="${2:?}"; shift ;;
    --license) LICENSE_KEY="${2:?}"; shift ;;
    --no-install-deps) INSTALL_DEPS=0 ;;
    --yes|-y) ASSUME_YES=1 ;;
    --force-os) FORCE_OS=1 ;;
    --replace-edition) REPLACE_EDITION=1 ;;
    --lang) LANG_OPT="${2:?}"; shift ;;
    -h|--help) SHOW_HELP=1 ;;
    *) BAD_OPT="$1" ;;
  esac
  shift
done

# An earlier install with --prefix is found through its service file.
if [ -z "$PREFIX" ] && [ -f "$SERVICE" ]; then
  prev_cfg="$(sed -n 's/^ExecStart=.*-config \([^ ]*\).*/\1/p' "$SERVICE" | head -1)"
  case "$prev_cfg" in */etc/config.json) PREFIX="${prev_cfg%/etc/config.json}" ;; esac
  prev_user="$(sed -n 's/^User=//p' "$SERVICE" | head -1)"
  [ -z "$RUN_AS" ] && [ -n "$prev_user" ] && [ "$prev_user" != uptimecast ] && RUN_AS="$prev_user"
fi
if [ -n "$PREFIX" ]; then
  case "$PREFIX" in /*) ;; *) echo "--prefix must be an absolute path" >&2; exit 1 ;; esac
  PREFIX="${PREFIX%/}"
  PREFIX_BIN=$PREFIX/bin/uptimecast
  ETC_DIR=$PREFIX/etc
  DATA_DIR=$PREFIX/data
  CRED_FILE=$PREFIX/credentials.txt
else
  PREFIX_BIN=/usr/local/bin/uptimecast
  ETC_DIR=/etc/uptimecast
  DATA_DIR=/var/lib/uptimecast
  CRED_FILE=/root/uptimecast-credentials.txt
fi
CONFIG=$ETC_DIR/config.json
[ -n "$RUN_AS" ] && SYS_USER="$RUN_AS"

valid_ident() { [[ "$1" =~ ^[a-z_][a-z0-9_]{0,62}$ ]]; }

run() {
  # Executes a command, or only prints it in --dry-run.
  if [ "$DRY_RUN" = 1 ]; then printf '    [dry-run] %s\n' "$*"; else "$@"; fi
}

random_secret() { head -c 48 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c "${1:-24}"; }

# ---- 1. the program, then the language ------------------------------------------
case "$(uname -m)" in
  x86_64|amd64) ARCH=amd64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  *) fatal "Unsupported architecture: $(uname -m)" ;;
esac
if [ -z "$BINARY" ]; then
  for c in "$VERSION_FILE_DIR/bin/uptimecast-linux-$ARCH" "$VERSION_FILE_DIR/uptimecast-linux-$ARCH" "$VERSION_FILE_DIR/uptimecast"; do
    [ -f "$c" ] && { BINARY="$c"; break; }
  done
fi
[ -n "$BINARY" ] && [ -f "$BINARY" ] || fatal "Can't find the $ARCH binary next to the installer. Use --binary PATH."
NEW_VERSION="$("$BINARY" version 2>/dev/null | awk '{print $2}')" || true
[ -n "$NEW_VERSION" ] || fatal "The binary $BINARY does not run on this system."
TBIN="$BINARY"

LANG_CODES=(); LANG_NAMES=()
while IFS=$'\t' read -r code name; do LANG_CODES+=("$code"); LANG_NAMES+=("$name"); done < <("$BINARY" i18n -list)
lang_known() { local c; for c in "${LANG_CODES[@]}"; do [ "$c" = "$1" ] && return 0; done; return 1; }
lang_name() { local i; for i in "${!LANG_CODES[@]}"; do [ "${LANG_CODES[$i]}" = "$1" ] && { echo "${LANG_NAMES[$i]}"; return; }; done; echo "$1"; }
L="$(sys_lang)"; lang_known "$L" || L=en

if [ -n "$LANG_OPT" ]; then
  lang_known "$LANG_OPT" || die inst.err.lang lang="$LANG_OPT" list="${LANG_CODES[*]}"
  L="$LANG_OPT"
fi
[ "$SHOW_HELP" = 1 ] && { usage; exit 0; }
[ -z "$BAD_OPT" ] || { usage; echo; die inst.err.option opt="$BAD_OPT"; }

# Root is needed even for --dry-run, to inspect PostgreSQL.
[ "$(id -u)" = 0 ] || die inst.err.root cmd="$0"

# Language: --lang, or the one of an earlier install, or ask (default: the system's).
LANG_CHOSEN=0
if [ -n "$LANG_OPT" ]; then
  LANG_CHOSEN=1
elif [ -f "$CONFIG" ] && prev_lang="$(sed -n 's/.*"lang"[[:space:]]*:[[:space:]]*"\([a-z]*\)".*/\1/p' "$CONFIG" | head -1)" && lang_known "$prev_lang"; then
  L="$prev_lang"
elif [ "$ASSUME_YES" = 0 ] && [ -t 0 ]; then
  def=1
  for i in "${!LANG_CODES[@]}"; do [ "${LANG_CODES[$i]}" = "$L" ] && def=$((i + 1)); done
  echo
  echo "UptimeCast — Language · Idioma · Langue · Idioma · اللغة · Dil · Sprache · Lingua · Язык · 语言"
  for i in "${!LANG_CODES[@]}"; do printf '  %2d) %s\n' $((i + 1)) "${LANG_NAMES[$i]}"; done
  while :; do
    read -r -p "[1-${#LANG_CODES[@]}, Enter = $def] " answer || answer=""
    [ -z "$answer" ] && answer=$def
    if [[ "$answer" =~ ^[0-9]+$ ]] && [ "$answer" -ge 1 ] && [ "$answer" -le "${#LANG_CODES[@]}" ]; then
      L="${LANG_CODES[$((answer - 1))]}"; break
    elif lang_known "$answer"; then
      L="$answer"; break
    fi
  done
  LANG_CHOSEN=1
  echo
fi

valid_ident "$DB_NAME" || die inst.err.dbname
valid_ident "$DB_USER" || die inst.err.dbuser
[[ "$PORT" =~ ^[0-9]+$ ]] && [ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ] || die inst.err.port port="$PORT"

[ -r /etc/os-release ] || die inst.err.os
. /etc/os-release
OS_OK=0
case "${ID:-}:${VERSION_ID:-}" in
  ubuntu:20.04|ubuntu:22.04|ubuntu:24.04|ubuntu:26.04|debian:11|debian:12|debian:13) OS_OK=1 ;;
esac
if [ "$OS_OK" = 0 ]; then
  [ "$FORCE_OS" = 1 ] || die inst.err.unsupported os="${PRETTY_NAME:-?}"
  warn inst.warn.unsupported os="${PRETTY_NAME:-?}"
fi
[ "${ID:-}:${VERSION_ID:-}" = "ubuntu:20.04" ] && warn inst.warn.ubuntu2004

HAS_SYSTEMD=0; [ -d /run/systemd/system ] && HAS_SYSTEMD=1

if [ -n "$RUN_AS" ]; then
  id "$RUN_AS" >/dev/null 2>&1 || die inst.err.nouser user="$RUN_AS"
  [ "$(id -u "$RUN_AS")" != 0 ] || die inst.err.rootuser
fi

# ---- 2. detect what is already on the server ------------------------------------
info inst.checking

UPGRADE=0
if [ -f "$CONFIG" ]; then
  UPGRADE=1
  INSTALL_ID="$(sed -n 's/.*"install_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONFIG" | head -1)"
  DB_URL="$(sed -n 's/.*"database_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONFIG" | head -1)"
  OLD_VERSION="$( [ -x "$PREFIX_BIN" ] && "$PREFIX_BIN" version 2>/dev/null | awk '{print $2}' || echo '?')"
  DB_NAME="${DB_URL##*/}"; DB_NAME="${DB_NAME%%\?*}"
  DB_USER="${DB_URL#*://}"; DB_USER="${DB_USER%%:*}"
  PORT="$(sed -n 's/.*"listen"[[:space:]]*:[[:space:]]*"[^"]*:\([0-9]*\)".*/\1/p' "$CONFIG" | head -1)"
  info inst.upgrade old="$OLD_VERSION" new="$NEW_VERSION"
fi

# A server running a private edition (version ending in -<edition>, such as
# the one with the iptv-org add-on) is only upgraded by that same edition.
# Installing the public package over it would hide the add-on, so stop unless
# --replace-edition is given. Its data is never deleted either way.
edition_of() { case "$1" in *-*[a-z]*) printf '%s' "${1##*-}" ;; esac; }
OLD_EDITION="$(edition_of "${OLD_VERSION:-}")"
NEW_EDITION="$(edition_of "$NEW_VERSION")"
case "$OLD_EDITION" in rc[0-9]*|dirty|g[0-9a-f]*) OLD_EDITION="" ;; esac
case "$NEW_EDITION" in rc[0-9]*|dirty|g[0-9a-f]*) NEW_EDITION="" ;; esac
if [ "$UPGRADE" = 1 ] && [ -n "$OLD_EDITION" ] && [ "$OLD_EDITION" != "$NEW_EDITION" ] && [ "${REPLACE_EDITION:-0}" != 1 ]; then
  die inst.err.edition old="$OLD_VERSION" new="$NEW_VERSION"
fi

have() { command -v "$1" >/dev/null 2>&1; }

if [ -n "$FFMPEG_BIN" ]; then
  [ -x "$FFMPEG_BIN" ] || die inst.err.ffmpegpath path="$FFMPEG_BIN"
  [ -n "$FFPROBE_BIN" ] || FFPROBE_BIN="$(dirname "$FFMPEG_BIN")/ffprobe"
  [ -x "$FFPROBE_BIN" ] || die inst.err.ffprobe path="$FFMPEG_BIN"
  HAVE_FFMPEG=1
else
  HAVE_FFMPEG=0; have ffmpeg && have ffprobe && HAVE_FFMPEG=1
  FFMPEG_BIN=ffmpeg; FFPROBE_BIN=ffprobe
fi
if [ "$HAVE_FFMPEG" = 1 ]; then
  FFV="$("$FFMPEG_BIN" -hide_banner -version 2>/dev/null | head -1 | awk '{print $3}')"
  info inst.ffmpeg.found ver="${FFV:-?}"
  # Read the help into a variable first: piping into "grep -q" can make ffmpeg
  # die of SIGPIPE, which pipefail would report as a missing option.
  hls_help="$("$FFMPEG_BIN" -hide_banner -h muxer=hls 2>/dev/null || true)"
  [[ "$hls_help" == *append_list* ]] \
    || warn inst.warn.ffmpeghls
fi
HAVE_PG=0; have psql && [ -d /usr/lib/postgresql ] && HAVE_PG=1
PG_RUNNING=0
pg_q() { runuser -u postgres -- env LC_ALL=C psql -X -v ON_ERROR_STOP=1 -tAq "$@"; }
if [ "$HAVE_PG" = 1 ] && pg_q -c 'SELECT 1' >/dev/null 2>&1; then PG_RUNNING=1; fi

if have mysql || have mariadb || [ -d /var/lib/mysql ]; then
  info inst.mysql
fi
if [ "$PG_RUNNING" = 1 ]; then
  OTHER_DBS="$(pg_q -c "SELECT count(*) FROM pg_database WHERE NOT datistemplate AND datname NOT IN ('postgres', '$DB_NAME')")"
  info inst.pg.found n="$OTHER_DBS"
  PG_PORT="$(pg_q -c 'SHOW port')"
elif [ "$HAVE_PG" = 1 ]; then
  die inst.err.pgdown
else
  PG_PORT=5432
fi

# The database and role must be new on a fresh install, or ours on an upgrade.
if [ "$PG_RUNNING" = 1 ]; then
  DB_EXISTS="$(pg_q -c "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'")"
  ROLE_EXISTS="$(pg_q -c "SELECT 1 FROM pg_roles WHERE rolname = '$DB_USER'")"
  if [ "$UPGRADE" = 0 ]; then
    [ -z "$DB_EXISTS" ] || die inst.err.dbexists db="$DB_NAME"
    [ -z "$ROLE_EXISTS" ] || die inst.err.roleexists role="$DB_USER"
  else
    [ -n "$DB_EXISTS" ] || die inst.err.dbmissing db="$DB_NAME"
    OWNER_ID="$(pg_q -d "$DB_NAME" -c "SELECT value FROM uptimecast_meta WHERE key = 'install_id'" 2>/dev/null || true)"
    [ -n "$OWNER_ID" ] && [ "$OWNER_ID" = "$INSTALL_ID" ] || die inst.err.dbnotours db="$DB_NAME"
    # Same protection for servers from before the edition label: the add-on's
    # tables are there and the new package does not carry it.
    if [ -z "$NEW_EDITION" ] && [ "${REPLACE_EDITION:-0}" != 1 ] \
       && [ -n "$(pg_q -d "$DB_NAME" -c "SELECT 1 FROM information_schema.tables WHERE table_name = 'iptvorg_lists'" 2>/dev/null || true)" ]; then
      die inst.err.edition old="$OLD_VERSION" new="$NEW_VERSION"
    fi
  fi
fi

# Port: never stop another service; pick a free one instead.
port_busy() {
  if have ss; then [ -n "$(ss -Hltn "sport = :$1" 2>/dev/null)" ]
  else (exec 3<>"/dev/tcp/127.0.0.1/$1") 2>/dev/null; fi
}
if [ "$UPGRADE" = 0 ] && port_busy "$PORT"; then
  [ "$PORT_SET" = 1 ] && die inst.err.portbusy port="$PORT"
  for p in $(seq $((PORT + 1)) $((PORT + 20))); do
    if ! port_busy "$p"; then
      warn inst.warn.portmoved port="$PORT" new="$p"
      PORT=$p; break
    fi
  done
  port_busy "$PORT" && die inst.err.noport from="$PORT" to="$((PORT + 20))"
fi

# ---- 3. plan --------------------------------------------------------------------
[ "$HAVE_FFMPEG" = 1 ] || plan inst.plan.ffmpeg
[ "$HAVE_PG" = 1 ] || plan inst.plan.pg
if [ "$UPGRADE" = 0 ]; then
  plan inst.plan.db role="$DB_USER" db="$DB_NAME"
  if [ -n "$RUN_AS" ]; then
    plan inst.plan.dirs.runas etc="$ETC_DIR" data="$DATA_DIR" user="$RUN_AS"
  else
    plan inst.plan.dirs user="$SYS_USER" etc="$ETC_DIR" data="$DATA_DIR"
  fi
  plan inst.plan.config config="$CONFIG" port="$PORT"
  plan inst.plan.admin user="$ADMIN_USER"
fi
plan inst.plan.binary ver="$NEW_VERSION" path="$PREFIX_BIN"
plan inst.plan.tables db="$DB_NAME"
{ [ "$UPGRADE" = 0 ] || [ "$LANG_CHOSEN" = 1 ]; } && plan inst.plan.lang lang="$(lang_name "$L")"
[ -n "$LICENSE_KEY" ] && plan inst.plan.license
if [ "$HAS_SYSTEMD" = 1 ]; then
  plan inst.plan.service
else
  plan inst.plan.nosystemd
fi

echo
t inst.plan.title
for p in "${PLAN[@]}"; do printf '  - %s\n' "$p"; done
echo

if [ "$DRY_RUN" = 1 ]; then
  t inst.dryrun
  exit 0
fi
if [ "$ASSUME_YES" = 0 ] && [ -t 0 ]; then
  read -r -p "$(t inst.confirm)" answer || answer=""
  ok=0
  IFS=',' read -ra yes_words <<<"$(t inst.yes),y,yes"
  for w in "${yes_words[@]}"; do [ -n "$answer" ] && [ "${answer,,}" = "${w,,}" ] && ok=1; done
  [ "$ok" = 1 ] || { t inst.cancelled; exit 1; }
fi

# ---- 4. dependencies ------------------------------------------------------------
if [ "$HAVE_FFMPEG" = 0 ] || [ "$HAVE_PG" = 0 ]; then
  [ "$INSTALL_DEPS" = 1 ] || die inst.err.nodeps
  pkgs=()
  [ "$HAVE_FFMPEG" = 1 ] || pkgs+=(ffmpeg)
  [ "$HAVE_PG" = 1 ] || pkgs+=(postgresql)
  info inst.installing pkgs="${pkgs[*]}"
  DEBIAN_FRONTEND=noninteractive apt-get update -q
  DEBIAN_FRONTEND=noninteractive apt-get install -y -q --no-install-recommends "${pkgs[@]}"
  if [ "$HAVE_PG" = 0 ]; then
    [ "$HAS_SYSTEMD" = 1 ] && systemctl enable --now postgresql >/dev/null 2>&1 || true
    for _ in $(seq 1 30); do pg_q -c 'SELECT 1' >/dev/null 2>&1 && break; sleep 1; done
    pg_q -c 'SELECT 1' >/dev/null 2>&1 || die inst.err.pgstart
    PG_PORT="$(pg_q -c 'SHOW port')"
  fi
fi

# ---- 5. system user, folders, binary -------------------------------------------
if [ -z "$RUN_AS" ] && ! id "$SYS_USER" >/dev/null 2>&1; then
  useradd --system --home-dir "$DATA_DIR" --no-create-home --shell /usr/sbin/nologin "$SYS_USER"
  getent group video >/dev/null && usermod -aG video "$SYS_USER" || true # GPU transcoding later
fi
SYS_GROUP="$(id -gn "$SYS_USER")"
if [ -n "$PREFIX" ]; then
  [ -d "$PREFIX" ] || install -d -m 0755 -o "$SYS_USER" -g "$SYS_GROUP" "$PREFIX"
  # UptimeCast's own folder must not be writable by other users, or anyone on
  # the server could replace its program. Only this folder is changed; its
  # owner stays the same.
  if [ -n "$(find "$PREFIX" -maxdepth 0 -perm /022)" ] || { have getfacl && getfacl -cp "$PREFIX" 2>/dev/null | grep -qE '^(user|group):[^:]+:.w|^default:'; }; then
    warn inst.warn.prefixperm path="$PREFIX"
    have setfacl && setfacl -b -k "$PREFIX" 2>/dev/null || true
    chmod 0755 "$PREFIX"; chmod g-s "$PREFIX"
  fi
  install -d -m 0755 -o root -g root "$PREFIX/bin"
  # The service user must be able to reach the folder; its parents are not changed.
  runuser -u "$SYS_USER" -- test -x "$PREFIX" \
    || die inst.err.prefixaccess user="$SYS_USER" path="$PREFIX"
fi
install -d -m 0750 -o root -g "$SYS_GROUP" "$ETC_DIR"
install -d -m 0750 -o "$SYS_USER" -g "$SYS_GROUP" "$DATA_DIR"

info inst.binary
install -m 0755 "$BINARY" "$PREFIX_BIN.new"
mv -f "$PREFIX_BIN.new" "$PREFIX_BIN"
# With --prefix, a shortcut lets you type "uptimecast" anywhere (never replaces
# another file). It is skipped when a parent folder lets other users rename
# things in it (writable by all, no sticky bit): they could swap the whole
# folder, and "sudo uptimecast" would then run their program as root.
UNSAFE_PARENT=""
if [ -n "$PREFIX" ]; then
  d="$(dirname "$PREFIX")"
  while [ "$d" != / ]; do
    if [ -n "$(find "$d" -maxdepth 0 -perm -002 ! -perm -1000)" ]; then UNSAFE_PARENT="$d"; break; fi
    d="$(dirname "$d")"
  done
fi
if [ -n "$PREFIX" ] && [ -z "$UNSAFE_PARENT" ] && { [ ! -e /usr/local/bin/uptimecast ] || [ "$(readlink /usr/local/bin/uptimecast)" = "$PREFIX_BIN" ]; }; then
  ln -sfn "$PREFIX_BIN" /usr/local/bin/uptimecast
elif [ -n "$UNSAFE_PARENT" ]; then
  [ "$(readlink /usr/local/bin/uptimecast 2>/dev/null)" = "$PREFIX_BIN" ] && rm -f /usr/local/bin/uptimecast
  warn inst.warn.unsafeparent dir="$UNSAFE_PARENT"
fi

# ---- 6. database: its own role and database, nothing else -------------------------
if [ "$UPGRADE" = 0 ]; then
  info inst.db.creating db="$DB_NAME"
  DB_PASS="$(random_secret 32)"
  INSTALL_ID="$(random_secret 20)"
  pg_q <<SQL
CREATE ROLE "$DB_USER" LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD '$DB_PASS';
CREATE DATABASE "$DB_NAME" OWNER "$DB_USER" ENCODING 'UTF8' TEMPLATE template0;
REVOKE CONNECT, TEMPORARY ON DATABASE "$DB_NAME" FROM PUBLIC;
GRANT CONNECT ON DATABASE "$DB_NAME" TO "$DB_USER";
SQL
  DB_URL="postgres://$DB_USER:$DB_PASS@127.0.0.1:$PG_PORT/$DB_NAME?sslmode=disable"

  # Make sure the role can log in over 127.0.0.1 with its password. Most systems
  # already allow it; if not, add one rule that only matches this database and
  # role, after backing up pg_hba.conf, and reload (no restart: other
  # applications are not interrupted).
  if ! PGPASSWORD="$DB_PASS" LC_ALL=C psql -X -h 127.0.0.1 -p "$PG_PORT" -U "$DB_USER" -d "$DB_NAME" -tAc 'SELECT 1' >/dev/null 2>&1; then
    HBA="$(pg_q -c 'SHOW hba_file')"
    BACKUP="$HBA.uptimecast-backup-$(date +%Y%m%d%H%M%S)"
    cp -a "$HBA" "$BACKUP"
    info inst.hba db="$DB_NAME" hba="$HBA" backup="$BACKUP"
    tmp="$(mktemp)"
    { printf 'host    %s    %s    127.0.0.1/32    scram-sha-256    # uptimecast\n' "$DB_NAME" "$DB_USER"; cat "$HBA"; } >"$tmp"
    cat "$tmp" >"$HBA"; rm -f "$tmp"
    pg_q -c 'SELECT pg_reload_conf()' >/dev/null
    sleep 1
    PGPASSWORD="$DB_PASS" LC_ALL=C psql -X -h 127.0.0.1 -p "$PG_PORT" -U "$DB_USER" -d "$DB_NAME" -tAc 'SELECT 1' >/dev/null 2>&1 \
      || die inst.err.dbconnect hba="$HBA" backup="$BACKUP"
  fi

  info inst.config.writing
  umask 027
  cat >"$CONFIG" <<JSON
{
  "listen": ":$PORT",
  "lang": "$L",
  "data_dir": "$DATA_DIR",
  "database_url": "$DB_URL",
  "ffmpeg": "$FFMPEG_BIN",
  "ffprobe": "$FFPROBE_BIN",
  "install_id": "$INSTALL_ID",
  "failover": {
    "stall_timeout": "20s",
    "startup_timeout": "20s",
    "probe_interval": "30s",
    "quality_interval": "10m",
    "stable_for": "5m"
  }
}
JSON
  chown root:"$SYS_GROUP" "$CONFIG"; chmod 0640 "$CONFIG"
fi

if [ "$UPGRADE" = 1 ] && grep -q '"stall_timeout": "5s"' "$CONFIG"; then
  # Before 0.9.1 a source was dropped after 5 s without data, too little for
  # internet sources that deliver in bursts. Only the old defaults change.
  cp -a "$CONFIG" "$CONFIG.backup-$(date +%Y%m%d%H%M%S)"
  sed -i -e 's/"stall_timeout": "5s"/"stall_timeout": "20s"/' -e 's/"startup_timeout": "15s"/"startup_timeout": "20s"/' "$CONFIG"
  info inst.timeouts
fi

if [ "$UPGRADE" = 1 ] && [ "$LANG_CHOSEN" = 1 ]; then
  if grep -q '"lang"[[:space:]]*:' "$CONFIG"; then
    sed -i "s/\"lang\"[[:space:]]*:[[:space:]]*\"[a-z]*\"/\"lang\": \"$L\"/" "$CONFIG"
  else
    sed -i "0,/\"listen\"[[:space:]]*:/s//\"lang\": \"$L\",\n  &/" "$CONFIG"
  fi
fi

info inst.tables
runuser -u "$SYS_USER" -- "$PREFIX_BIN" migrate -config "$CONFIG" >/dev/null
if [ "$UPGRADE" = 0 ]; then
  # Mark the database as ours, so upgrades and the uninstaller can tell.
  pg_q -d "$DB_NAME" -c "INSERT INTO uptimecast_meta(key, value) VALUES ('install_id', '$INSTALL_ID') ON CONFLICT (key) DO NOTHING"
fi

# ---- 7. administrator ---------------------------------------------------------
if [ "$UPGRADE" = 0 ]; then
  GENERATED=0
  if [ -z "$ADMIN_PASS" ]; then ADMIN_PASS="$(random_secret 16)"; GENERATED=1; fi
  printf '%s\n' "$ADMIN_PASS" | runuser -u "$SYS_USER" -- "$PREFIX_BIN" admin create -user "$ADMIN_USER" -password-stdin -config "$CONFIG" >/dev/null
fi

if [ -n "$LICENSE_KEY" ]; then
  runuser -u "$SYS_USER" -- "$PREFIX_BIN" license set "$LICENSE_KEY" -config "$CONFIG" \
    || warn inst.warn.license
fi

# ---- 8. service -----------------------------------------------------------------
if [ "$HAS_SYSTEMD" = 1 ]; then
  # A folder under /home stays readable (and its data folder writable); the rest of /home stays hidden.
  case "$PREFIX" in /home/*|/root/*) PROTECT_HOME=read-only ;; *) PROTECT_HOME=true ;; esac
  cat >"$SERVICE" <<UNIT
[Unit]
Description=UptimeCast streaming panel
After=network-online.target postgresql.service
Wants=network-online.target

[Service]
User=$SYS_USER
Group=$SYS_GROUP
ExecStart=$PREFIX_BIN serve -config $CONFIG
Restart=always
RestartSec=3
# The panel's "Shut down" button exits with 64: stay stopped, not failed.
RestartPreventExitStatus=64
SuccessExitStatus=64 75
LimitNOFILE=65536
# Channels are live: when the server is busy (e.g. other apps transcoding),
# UptimeCast and its FFmpeg pulls get CPU and disk first. It only copies
# streams, so this costs the other apps almost nothing.
CPUWeight=1000
IOWeight=1000
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=$PROTECT_HOME
PrivateTmp=true
ReadWritePaths=$DATA_DIR

[Install]
WantedBy=multi-user.target
UNIT
  systemctl daemon-reload
  systemctl enable uptimecast >/dev/null 2>&1
  systemctl restart uptimecast
  for _ in $(seq 1 15); do
    (exec 3<>"/dev/tcp/127.0.0.1/$PORT") 2>/dev/null && break; sleep 1
  done
  systemctl is-active --quiet uptimecast || die inst.err.service
fi

# ---- 9. done --------------------------------------------------------------------
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; IP="${IP:-SERVER}"
echo
if [ "$UPGRADE" = 1 ]; then
  info inst.upgraded ver="$NEW_VERSION"
else
  info inst.installed ver="$NEW_VERSION"
  echo
  printf '  %s %s\n' "$(t inst.done.panel)" "http://$IP:$PORT" "$(t inst.done.user)" "$ADMIN_USER" "$(t inst.done.lang)" "$(lang_name "$L")"
  if [ "$GENERATED" = 1 ]; then
    printf '  %s %s\n' "$(t inst.done.pass)" "$ADMIN_PASS"
    umask 077
    printf 'UptimeCast panel: http://%s:%s\nuser: %s\npassword: %s\n' "$IP" "$PORT" "$ADMIN_USER" "$ADMIN_PASS" >"$CRED_FILE"
    chown root:root "$CRED_FILE"; chmod 0600 "$CRED_FILE"
    printf '  %s\n' "$(t inst.done.saved file="$CRED_FILE" cmd="sudo -u $SYS_USER $PREFIX_BIN admin password -user $ADMIN_USER -config $CONFIG")"
  fi
fi
if have ufw && ufw status 2>/dev/null | grep -q "Status: active"; then
  warn inst.warn.ufw port="$PORT"
fi
if [ "$HAS_SYSTEMD" = 0 ]; then
  warn inst.warn.nosystemd
  printf '    sudo -u %s %s serve -config %s\n' "$SYS_USER" "$PREFIX_BIN" "$CONFIG"
fi
