#!/usr/bin/env bash
# UptimeCast uninstaller.
#
# Removes only UptimeCast's own service, binary and files. Its database is
# KEPT unless you pass --purge-database and confirm, and even then only the
# database marked as belonging to this installation is removed.
#
#   sudo ./uninstall.sh                     remove the program, keep the data
#   sudo ./uninstall.sh --purge-database    also delete UptimeCast's own database
#   sudo ./uninstall.sh --lang es           in Spanish (default: the installed panel's language)
set -Eeuo pipefail

SERVICE=/etc/systemd/system/uptimecast.service
SYS_USER=uptimecast
PREFIX=""
PURGE_DB=0
ASSUME_YES=0
LANG_OPT=""
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Texts come from the uptimecast program (uptimecast i18n), in the panel's
# ten languages. A private copy is kept so they still work once it is removed.
TBIN=""
L=en
t() {
  local key=$1; shift
  if [ -n "$TBIN" ] && "$TBIN" i18n -lang "$L" "$key" "$@" 2>/dev/null; then return 0; fi
  printf '%s\n' "$key"
}
info() { printf '\033[1m==>\033[0m %s\n' "$(t "$@")"; }
die()  { printf '\033[31mxx\033[0m  %s\n' "$(t "$@")" >&2; exit 1; }
case "${LC_ALL:-${LC_MESSAGES:-${LANG:-}}}" in
  es*) L=es ;; fr*) L=fr ;; pt*) L=pt ;; ar*) L=ar ;; tr*) L=tr ;; de*) L=de ;; it*) L=it ;; ru*) L=ru ;; zh*) L=zh ;;
esac

while [ $# -gt 0 ]; do
  case "$1" in
    --purge-database) PURGE_DB=1 ;;
    --yes|-y) ASSUME_YES=1 ;;
    --prefix) PREFIX="${2:?}"; shift ;;
    --lang) LANG_OPT="${2:?}"; shift ;;
    -h|--help) SHOW_HELP=1 ;;
    *) BAD_OPT="$1" ;;
  esac
  shift
done

# Find a --prefix install through its service file.
if [ -f "$SERVICE" ]; then
  prev_cfg="$(sed -n 's/^ExecStart=.*-config \([^ ]*\).*/\1/p' "$SERVICE" | head -1)"
  [ -z "$PREFIX" ] && case "$prev_cfg" in */etc/config.json) PREFIX="${prev_cfg%/etc/config.json}" ;; esac
  prev_user="$(sed -n 's/^User=//p' "$SERVICE" | head -1)"
  [ -n "$prev_user" ] && SYS_USER="$prev_user"
fi
if [ -n "$PREFIX" ]; then
  PREFIX="${PREFIX%/}"; PREFIX_BIN=$PREFIX/bin/uptimecast; ETC_DIR=$PREFIX/etc; DATA_DIR=$PREFIX/data
else
  PREFIX_BIN=/usr/local/bin/uptimecast; ETC_DIR=/etc/uptimecast; DATA_DIR=/var/lib/uptimecast
fi
CONFIG=$ETC_DIR/config.json

# The program for the texts: the one shipped next to this script, else a
# private copy of the installed one (it is about to be removed).
case "$(uname -m)" in x86_64|amd64) ARCH=amd64 ;; aarch64|arm64) ARCH=arm64 ;; *) ARCH="" ;; esac
for c in "$SCRIPT_DIR/bin/uptimecast-linux-$ARCH" "$PREFIX_BIN"; do
  if [ -f "$c" ] && "$c" version >/dev/null 2>&1; then
    TBIN="$(mktemp)"; cp "$c" "$TBIN"; chmod 700 "$TBIN"; trap 'rm -f "$TBIN"' EXIT
    break
  fi
done
if [ -n "$LANG_OPT" ]; then
  L="$LANG_OPT"
elif [ -r "$CONFIG" ]; then
  cfg_lang="$(sed -n 's/.*"lang"[[:space:]]*:[[:space:]]*"\([a-z]*\)".*/\1/p' "$CONFIG" | head -1)"
  [ -n "$cfg_lang" ] && L="$cfg_lang"
fi
[ "${SHOW_HELP:-0}" = 1 ] && { t un.usage cmd="$0"; exit 0; }
[ -z "${BAD_OPT:-}" ] || { t un.usage cmd="$0"; die inst.err.option opt="$BAD_OPT"; }
[ "$(id -u)" = 0 ] || die un.err.root cmd="$0"

DB_URL=""; INSTALL_ID=""
if [ -f "$CONFIG" ]; then
  DB_URL="$(sed -n 's/.*"database_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONFIG" | head -1)"
  INSTALL_ID="$(sed -n 's/.*"install_id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONFIG" | head -1)"
fi
DB_NAME="${DB_URL##*/}"; DB_NAME="${DB_NAME%%\?*}"
DB_USER="${DB_URL#*://}"; DB_USER="${DB_USER%%:*}"

if [ "$ASSUME_YES" = 0 ] && [ -t 0 ]; then
  if [ "$PURGE_DB" = 1 ]; then
    t un.purge.warn db="$DB_NAME"
    read -r -p "$(t un.purge.type db="$DB_NAME")" answer || answer=""
    [ "$answer" = "$DB_NAME" ] || die inst.cancelled
  else
    t un.keep db="$DB_NAME"
    read -r -p "$(t inst.confirm)" answer || answer=""
    ok=0
    IFS=',' read -ra yes_words <<<"$(t inst.yes),y,yes"
    for w in "${yes_words[@]}"; do [ -n "$answer" ] && [ "${answer,,}" = "${w,,}" ] && ok=1; done
    [ "$ok" = 1 ] || die inst.cancelled
  fi
fi

if [ -f "$SERVICE" ]; then
  info un.stopping
  systemctl disable --now uptimecast >/dev/null 2>&1 || true
  rm -f "$SERVICE"
  systemctl daemon-reload 2>/dev/null || true
fi
# Only UptimeCast's own process; its FFmpeg children exit with it. Nothing else is stopped.
pkill -u "$SYS_USER" -f "^$PREFIX_BIN serve" 2>/dev/null || true
rm -f "$PREFIX_BIN"
[ "$(readlink /usr/local/bin/uptimecast 2>/dev/null)" = "$PREFIX_BIN" ] && rm -f /usr/local/bin/uptimecast
[ -n "$PREFIX" ] && rmdir "$PREFIX/bin" 2>/dev/null || true
rm -rf "$DATA_DIR/hls"
info un.removed

if [ "$PURGE_DB" = 1 ]; then
  [ -n "$DB_NAME" ] && [ -n "$INSTALL_ID" ] || die un.err.noconfig
  pg_q() { runuser -u postgres -- env LC_ALL=C psql -X -v ON_ERROR_STOP=1 -tAq "$@"; }
  OWNER_ID="$(pg_q -d "$DB_NAME" -c "SELECT value FROM uptimecast_meta WHERE key = 'install_id'" 2>/dev/null || true)"
  [ -n "$OWNER_ID" ] && [ "$OWNER_ID" = "$INSTALL_ID" ] || die un.err.notours db="$DB_NAME"
  info un.deleting db="$DB_NAME" role="$DB_USER"
  pg_q -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid()" >/dev/null
  pg_q -c "DROP DATABASE \"$DB_NAME\""
  pg_q -c "DROP ROLE IF EXISTS \"$DB_USER\""
  HBA="$(pg_q -c 'SHOW hba_file')"
  if grep -q '# uptimecast$' "$HBA"; then
    cp -a "$HBA" "$HBA.uptimecast-uninstall-$(date +%Y%m%d%H%M%S)"
    sed -i '/# uptimecast$/d' "$HBA"
    pg_q -c 'SELECT pg_reload_conf()' >/dev/null
  fi
  rm -rf "$ETC_DIR" "$DATA_DIR"
  [ -n "$PREFIX" ] && rm -f "$PREFIX/credentials.txt" && rmdir "$PREFIX" 2>/dev/null || true
  # Only the system user the installer created; never a person's account.
  if [ "$SYS_USER" = uptimecast ] && [ "$(id -u uptimecast 2>/dev/null || echo 0)" -lt 1000 ]; then
    userdel uptimecast 2>/dev/null || true
  fi
  info un.purged
else
  info un.kept db="$DB_NAME" config="$CONFIG"
fi
